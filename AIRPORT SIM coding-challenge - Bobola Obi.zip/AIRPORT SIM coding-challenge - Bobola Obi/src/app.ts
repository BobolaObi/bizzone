import express from 'express';

const app = express();
// My middleware to parse incoming JSON payloads
app.use(express.json());

// Home page endpoint for simple welcome message
app.get('/', (req, res) => {
  res.send('Welcome');
});

//Inlcude endpoints for data to eb collected eg flights

export default app;