import dotenv from 'dotenv';

dotenv.config();

const config = {
    mongoURI: process.env.MONGO_URI || 'mongodb://myAccountName:myPassword@undefined/?replicaSet=atlas-j1c3qw-shard-0&ssl=true&authSource=admin',
    port: process.env.PORT || 5000
};

export default config;