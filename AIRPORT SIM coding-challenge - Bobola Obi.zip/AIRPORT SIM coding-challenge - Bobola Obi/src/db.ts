import mongoose from 'mongoose';
import { MongoClient, ServerApiVersion } from 'mongodb';

// Connect to MongoDB using Mongoose (object data modeling for MongoDB)
const connectWithMongoose = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://myAccountName:myPassword@undefined/?replicaSet=atlas-j1c3qw-shard-0&ssl=true&authSource=admin';

  try {
    await mongoose.connect(uri);
    console.log('Mongoose connected successfully');
  } catch (error) {
    console.error('Mongoose connection error:', error);
    process.exit(1); // Terminate if connection fails
  }
};

// Connect to MongoDB using the native MongoDB driver
const connectWithMongoClient = async () => {
  const uri = "mongodb://myAccountName:myPassword@undefined/?replicaSet=atlas-j1c3qw-shard-0&ssl=true&authSource=admin";
  const client = new MongoClient(uri, {
    serverApi: {
      version: ServerApiVersion.v1,
      strict: true,
      deprecationErrors: true,
    }
  });

  try {
    await client.connect();
    await client.db("admin").command({ ping: 1 }); // Test connection with a ping command
    console.log("Successfully connected to MongoDB with MongoClient!");
  } catch (error) {
    console.error('MongoClient connection error:', error);
    process.exit(1); // Terminate if connection fails
  } finally {
    await client.close();
  }
};

// Function to select which method to use for database connection
const connectToDB = async (useMongoose = true) => {
  if (useMongoose) {
    await connectWithMongoose();
  } else {
    await connectWithMongoClient();
  }
};

export { connectToDB };
