import mongoose, { Document, Schema } from 'mongoose';


// Define an interface for Flight to enforce types on flight documents.
export interface Flight extends Document {
  flightNumber: string;
  origin: string;
  destination: string;
  departureTime: Date;
  arrivalTime: Date;
}

// Define the schema for the Flight model, to map to  MongoDB collection.
const FlightSchema: Schema = new Schema({
  flightNumber: { type: String, required: true },
  origin: { type: String, required: true },
  destination: { type: String, required: true },
  departureTime: { type: Date, required: true },
  arrivalTime: { type: Date, required: true },
});

// Create the Mongoose model for Flight, using the FlightSchema.
const FlightModel = mongoose.model<Flight>('Flight', FlightSchema);
export default FlightModel;
