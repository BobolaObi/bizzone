import FlightModel, { Flight } from '../models/flight.model';

class FlightService {
  // Create a new flight document and save it to the database
  async createFlight(flightData: Flight) {
    const flight = new FlightModel(flightData);
    return await flight.save();
  }

  // Retrieve all flights from the database
  async getAllFlights() {
    return await FlightModel.find();
  }

  // Other CRUD methods go here
}

export default new FlightService();
